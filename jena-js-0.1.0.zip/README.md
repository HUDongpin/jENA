# jENA / ENA.js

Standalone TypeScript/JavaScript library for Epistemic Network Analysis, ported from **rENA** for browser and Node runtimes.

This is not a Next.js app and does not require React, Next, R, Rserve, OpenCPU, or any server-side runtime. The package builds to ESM JavaScript plus TypeScript declarations.

## Install

```bash
npm install jena-js
```

For local development in this repository:

```bash
npm install
npm run typecheck
npm test
npm run build
```

## Usage

```ts
import { ena } from 'jena-js';

const set = ena({
  rows: [
    { unit: 'u1', conv: 'c1', A: 1, B: 0, C: 0 },
    { unit: 'u1', conv: 'c1', A: 0, B: 1, C: 0 },
    { unit: 'u2', conv: 'c1', A: 1, B: 1, C: 0 }
  ],
  units: ['unit'],
  conversation: ['conv'],
  codes: ['A', 'B', 'C'],
  windowSizeBack: 2,
  dimensions: 2
});

console.log(set.connectionCounts);
console.log(set.points);
console.log(set.rotation.nodes);
```

## Package Entrypoints

```ts
import { ena, accumulateData, makeSet } from 'jena-js';
import { rowsToCoOccurrences } from 'jena-js/core';
import { createENAPlotModel, toPlotly } from 'jena-js/plot';
import { createENAWorkerClient } from 'jena-js/browser';
```

The worker entrypoint is exported as `jena-js/browser/worker`.

## Golden Fixtures

R is used only for development-time golden fixture generation:

```bash
npm run goldens:r
npm run goldens:compare
```

Runtime remains pure JavaScript.

## License

GPL-3.0-only. The original rENA source is GPL-3-compatible, and this port preserves that licensing posture.
